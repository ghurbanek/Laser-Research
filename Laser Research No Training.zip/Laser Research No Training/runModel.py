import math
import random

from train_model import predict_aberrations
from beam import generate_and_save_plot

aberrations : dict[str, list[int]] = {
    #"tx" : [1,1],
    #"ty" : [1,-1],   
    "ax" : [2,2],
    "ay" : [2,-2],
    "cx" : [3,1],
    "cy" : [3,-1],
    #"trx" : [3,3],
    #"try" : [3,-3],
}

wv : float = 700
waist : float = 1.0
radial : int = 0
azimuthal : int = 1
grid_sz = 256

def run_model(znt : list):
    generate_and_save_plot(
        "test_beam.png",
        wavelength_nm = wv,
        w0_mm = waist,
        p = radial,
        ell = azimuthal,
        propagation_m=1.0,
        grid_size = grid_sz,
        window_mm=8.0,
        zernike_terms = znt,
        image_type="aberrated",
        folder = None,
    )

    print(f"Predicted aberrations: {predict_aberrations("test_beam.png")}")
    print(f"Generated image aberrations: {znt}")

if __name__ == "__main__":
    run_model([[aberrations.get(i)[0], aberrations.get(i)[1], random.randint(0,50) /100] for i in aberrations])
    