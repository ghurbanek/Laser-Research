from beam import generate_and_save_plot
from pathlib import Path
from matplotlib.image import imsave
from itertools import product
import json
from PIL.PngImagePlugin import PngInfo
import numpy as np

#Aberrations shorthand conversion
"""
Piston - ps
Tilt X - tx
Tilt Y - ty
Defocus - df
Astigmatism X - ax
Astigmatism Y - ay
Coma X - cx
Coma Y - cy
Trefoil X - trx
Trefoil Y -try
Primary Spherical - prs
"""
#Possible Aberrations
#Piston, Defocus, Primary Spherical is excluded
aberrations : dict[str, list[int]] = {
    #"tx" : [1,1],
    #"ty" : [1,-1],   
    "ax" : [2,2],
    "ay" : [2,-2],
    "cx" : [3,1],
    "cy" : [3,-1],
    #"trx" : [3,3],
    #"try" : [3,-3],
}

#Parameters for ideal beam
wv : float = 700
waist : float = 1.0
radial : int = 0
azimuthal : int = 1
grid_sz = 256


#Generates plot and saves image with metadata that corresponds to the zernike terms
def saveImage(img_name : str, zernike_terms, folder, imageType):
    #gen plot returns (path, image_format, data)
    imageData : tuple = generate_and_save_plot(
        f"{img_name}.png",
        wavelength_nm = wv,
        w0_mm = waist,
        p = radial,
        ell = azimuthal,
        propagation_m=1.0,
        grid_size = grid_sz,
        window_mm=8.0,
        zernike_terms=zernike_terms,
        image_type= imageType,
        folder = folder,
    )

    metadata = PngInfo()
    metadata.add_text("zernike_terms", json.dumps(zernike_terms))

    imsave(
        imageData[0], 
        imageData[2], 
        cmap="gray", 
        origin="lower", 
        vmin=0, 
        vmax=1,
        format=imageData[1],
        pil_kwargs= {"pnginfo" : metadata}
    )


#Start and Stop are inclusive
def create_dataset(high : float = .5, step : float = .1):
    #Creates Data Set Folder
    data = Path("training_data_2")
    data.mkdir(exist_ok=True)

    #Ideal Beam, Creation
    saveImage("ideal", [], data, "ideal")

    #Creates Sub Folder
    nonIdeal = Path(data / f"abberations")
    nonIdeal.mkdir(exist_ok=True)
    
    #Generates Aberration range
    values = [round(float(i), int((1/step) / 10)) for i in np.arange(0.0, high + step, step)]

    #Generates every assignment of values from number of abberations
    aberration = [i for i in aberrations]

    print(f"Generating images for {aberration} at variable strength from 0 - {high} with a step size of {step}.\nWith a total of {int((high/step + 1) ** len(aberration))} images. Yielding a data size of about {round((int((high/step + 1) ** len(aberration)) * 64 * 64 * 4) / (1024 ** 3), 2)} Gigabytes.")

    #Goes through each possible strength value
    for strengths in product(values, repeat = len(aberrations)):
        zernike_terms = []
        #Goes through each aberration with its respected strength and adds it 
        for n in range(len(aberrations)):
            zernike_terms.append([aberrations.get(aberration[n])[0], aberrations.get(aberration[n])[1], strengths[n]])
        saveImage("".join(str(strengths)), zernike_terms, nonIdeal, "aberrated")
             

if __name__ == "__main__":
    create_dataset(high = .5, step =.04)
    print("Generation completed.")