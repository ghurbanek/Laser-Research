"""Learn multiple simultaneous Zernike aberration coefficients from PNGs.

Install:
    python -m pip install numpy pillow scikit-learn joblib

Put this script next to training_data_2/ and run:
    python train_model.py
    python train_model.py train --data-folder training_data_2
    python train_model.py predict new_beam.png
    python train_model.py predict new_beam.png --threshold 0.03

Labels come from each PNG's JSON ``zernike_terms`` metadata, exactly as written
by generateAberrationImages. Filenames and folder names are not labels. The
default is grayscale (L), matching that generator's cmap="gray". Prediction
reads only pixels, never the image's metadata. Keep the beam parameters, crop,
orientation, colormap, and field of view consistent with training.

Each discovered (n, m) term has its own output coefficient. Omitted terms and
the ideal image (metadata []) have coefficient zero. Signed coefficients are
accepted, but intensity images may not uniquely determine some phase terms.
Held-out errors measure performance on this simulator dataset, not real beams.

API:
    predict_aberrations(image_path) -> {"ax": coefficient, "ay": coefficient, ...}
    predict_zernike_terms(image_path) -> [(n, m, coefficient), ...]
    predict_aberration(image_path) -> (strongest_term_name, coefficient)

The last function retains runModel.py's old two-value interface. It reports
only the strongest estimated term; use the plural API or CLI for combinations.
Retrain before predicting: the old classifier model has a different format.
"""

import argparse
import hashlib
import json
import warnings
from pathlib import Path

import joblib
import numpy as np
from PIL import Image
from sklearn.compose import TransformedTargetRegressor
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import mean_absolute_error, precision_recall_fscore_support
from sklearn.model_selection import GroupShuffleSplit
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


SCRIPT_FOLDER = Path(__file__).resolve().parent
DATA_FOLDER = SCRIPT_FOLDER / "training_data_2"
MODEL_PATH = SCRIPT_FOLDER / "aberration_strength_model.joblib"
IMAGE_SIZE = (64, 64)
COLOR_MODE = "L"
RANDOM_STATE = 42
PRESENCE_THRESHOLD = 0.02
FORMAT_VERSION = 2

# These are display names only. Metadata determines which terms are trained.
TERM_NAMES = {
    (0, 0): "ps", (1, 1): "tx", (1, -1): "ty", (2, 0): "df",
    (2, 2): "ax", (2, -2): "ay", (3, 1): "cx", (3, -1): "cy",
    (3, 3): "trx", (3, -3): "try", (4, 0): "prs",
}


def term_name(term):
    return TERM_NAMES.get(tuple(term), f"Z({term[0]},{term[1]})")


def load_image(image_path, image_size=IMAGE_SIZE, color_mode=COLOR_MODE):
    """Prepare training and inference pixels identically."""
    if color_mode not in ("L", "RGB"):
        raise ValueError("color_mode must be 'L' or 'RGB'.")
    with Image.open(image_path) as image:
        image = image.convert(color_mode).resize(
            tuple(image_size), resample=Image.Resampling.LANCZOS
        )
        return (np.asarray(image, dtype=np.float32) / 255.0).ravel()


def read_zernike_metadata(image_path):
    """Read labels without importing or executing the generator or beam.py."""
    with Image.open(image_path) as image:
        raw = image.info.get("zernike_terms")
    if raw is None:
        raise ValueError(
            f"Missing 'zernike_terms' PNG metadata: {image_path}. "
            "Use PNGs saved by your metadata-enabled generator."
        )
    try:
        terms = json.loads(raw)
    except (TypeError, ValueError) as error:
        raise ValueError(f"Invalid zernike_terms JSON: {image_path}") from error
    if not isinstance(terms, list):
        raise ValueError(f"zernike_terms must be a list: {image_path}")

    coefficients = {}
    for term in terms:
        if not isinstance(term, (list, tuple)) or len(term) != 3:
            raise ValueError(f"Expected [n, m, coefficient], got {term!r}: {image_path}")
        n, m, coefficient = term
        if (type(n) is not int or type(m) is not int or n < 0
                or abs(m) > n or (n - abs(m)) % 2 != 0):
            raise ValueError(f"Invalid Zernike indices {n!r}, {m!r}: {image_path}")
        if isinstance(coefficient, bool) or not isinstance(coefficient, (int, float)):
            raise ValueError(f"Coefficient must be a number: {image_path}")
        coefficient = float(coefficient)
        if not np.isfinite(coefficient):
            raise ValueError(f"Coefficient must be finite: {image_path}")
        # Repeated identical terms contribute additively to beam.py's phase.
        coefficients[(n, m)] = coefficients.get((n, m), 0.0) + coefficient
        if not np.isfinite(coefficients[(n, m)]):
            raise ValueError(f"Combined coefficient is not finite: {image_path}")
    return coefficients


def load_dataset(data_folder=DATA_FOLDER, image_size=IMAGE_SIZE, color_mode=COLOR_MODE):
    """Return pixels X, coefficient vectors Y, ordered terms, and pixel groups."""
    data_folder = Path(data_folder)
    if not data_folder.is_dir():
        raise ValueError(f"Dataset folder does not exist: {data_folder}")
    paths = sorted(path for path in data_folder.rglob("*")
                   if path.is_file() and path.suffix.lower() == ".png")
    if not paths:
        raise ValueError(f"No PNG images found in {data_folder}")

    labels = []
    discovered_terms = set()
    for path in paths:
        coefficients = read_zernike_metadata(path)
        labels.append(coefficients)
        discovered_terms.update(coefficients)
    terms = sorted(discovered_terms)
    if not terms:
        raise ValueError("Dataset contains only ideal labels; no Zernike terms to learn.")

    # Allocate once rather than storing and stacking thousands of pixel arrays.
    first_features = load_image(paths[0], image_size, color_mode)
    X = np.empty((len(paths), len(first_features)), dtype=np.float32)
    Y = np.zeros((len(paths), len(terms)), dtype=np.float64)
    groups = np.empty(len(paths), dtype=object)
    seen = {}
    for i, (path, coefficients) in enumerate(zip(paths, labels)):
        X[i] = first_features if i == 0 else load_image(path, image_size, color_mode)
        Y[i] = [coefficients.get(term, 0.0) for term in terms]
        group = hashlib.sha256(X[i].tobytes()).hexdigest()
        groups[i] = group
        if group in seen:
            previous = seen[group]
            if not np.allclose(Y[i], Y[previous], rtol=0, atol=1e-12):
                raise ValueError(
                    f"Identical processed pixels have different coefficients: "
                    f"{paths[previous]} and {path}. These targets cannot be "
                    "distinguished at this image resolution; increase --image-size "
                    "or check for phase terms unobservable in intensity."
                )
        else:
            seen[group] = i
        if (i + 1) % 1000 == 0:
            print(f"Loaded {i + 1}/{len(paths)} images", flush=True)

    # Remove redundant copies, including ideal.png versus an all-zero combination.
    unique_indices = np.asarray(list(seen.values()))
    duplicates = len(paths) - len(unique_indices)
    if duplicates:
        X, Y, groups = X[unique_indices], Y[unique_indices], groups[unique_indices]
    if len(X) < 10:
        raise ValueError("Use at least ten distinct images for training and evaluation.")
    print(f"Images: {len(paths)} | Distinct inputs: {len(X)} | Duplicates removed: {duplicates}")
    print("Outputs:", ", ".join(f"{term_name(t)} {t}" for t in terms))
    print("Ideal/all-zero examples:", int(np.all(Y == 0, axis=1).sum()))
    return X, Y, terms, groups


def train_model(data_folder=DATA_FOLDER, model_path=MODEL_PATH,
                image_size=IMAGE_SIZE, color_mode=COLOR_MODE,
                threshold=PRESENCE_THRESHOLD, max_iter=300, test_size=0.20):
    """Train a neural-network regressor with one coefficient output per term."""
    if not np.isfinite(threshold) or threshold <= 0:
        raise ValueError("threshold must be finite and positive.")
    if max_iter < 1 or not 0 < test_size < 1:
        raise ValueError("max_iter must be positive; test_size must be between 0 and 1.")
    if len(image_size) != 2 or any(size < 1 for size in image_size):
        raise ValueError("image_size must contain two positive dimensions.")
    X, Y, terms, groups = load_dataset(data_folder, image_size, color_mode)
    splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=RANDOM_STATE)
    train_indices, test_indices = next(splitter.split(X, Y, groups))
    if len(train_indices) < 5 or len(test_indices) < 2:
        raise ValueError("Split needs at least five training images and two test images.")
    X_train, X_test = X[train_indices], X[test_indices]
    Y_train, Y_test = Y[train_indices], Y[test_indices]
    del X, Y

    for j, term in enumerate(terms):
        if np.unique(Y_train[:, j]).size < 2:
            warnings.warn(
                f"{term_name(term)} has only one coefficient in the training split; "
                "the model cannot learn how this term varies. Add more examples."
            )

    # Input and output scaling are fitted on the training split only. Unlike an
    # RBF SVM per combination, this model learns all coefficients simultaneously.
    regressor = make_pipeline(
        StandardScaler(),
        MLPRegressor(
            hidden_layer_sizes=(128, 64), activation="relu", solver="adam",
            batch_size=min(128, max(1, int(len(X_train) * 0.8))),
            max_iter=max_iter, early_stopping=len(X_train) >= 30,
            validation_fraction=0.15, n_iter_no_change=20, tol=1e-4,
            random_state=RANDOM_STATE,
        ),
    )
    model = TransformedTargetRegressor(regressor=regressor, transformer=StandardScaler())
    print(f"Training images: {len(X_train)} | Held-out test images: {len(X_test)}", flush=True)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(X_train, Y_train)
    for warning in caught:
        warnings.warn(str(warning.message), warning.category)
    predictions = np.asarray(model.predict(X_test)).reshape(len(X_test), len(terms))
    # Evaluate raw estimates; clipping and presence thresholds must not hide errors.
    mae = mean_absolute_error(Y_test, predictions, multioutput="raw_values")
    true_present = np.abs(Y_test) >= threshold
    predicted_present = np.abs(predictions) >= threshold
    precision, recall, f1, _ = precision_recall_fscore_support(
        true_present.ravel(), predicted_present.ravel(), average="binary", zero_division=0
    )
    exact_presence = float(np.all(true_present == predicted_present, axis=1).mean())
    print("Held-out coefficient MAE (waves):")
    for term, error in zip(terms, mae):
        print(f"  {term_name(term):>8}: {error:.6f}")
    print(f"Mean coefficient MAE: {float(mae.mean()):.6f}")
    print(f"Presence precision: {precision:.3f} | recall: {recall:.3f} | F1: {f1:.3f}")
    print(f"All-term presence match at threshold {threshold:g}: {exact_presence:.1%}")

    artifact = {
        "format_version": FORMAT_VERSION, "model": model,
        "terms": [tuple(term) for term in terms],
        "term_names": [term_name(term) for term in terms],
        "image_size": tuple(image_size), "color_mode": color_mode,
        "presence_threshold": float(threshold),
        "strength_ranges": np.column_stack((Y_train.min(axis=0), Y_train.max(axis=0))),
        "target": "Zernike coefficients in waves, using beam.py's normalization",
        "metrics": {
            "coefficient_mae": dict(zip((term_name(t) for t in terms), map(float, mae))),
            "mean_coefficient_mae": float(mae.mean()),
            "presence_precision": float(precision), "presence_recall": float(recall),
            "presence_f1": float(f1), "exact_presence_accuracy": exact_presence,
            "train_images": len(X_train), "test_images": len(X_test),
        },
        "sklearn_version": __import__("sklearn").__version__,
    }
    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, model_path)
    print(f"Saved model to: {model_path.resolve()}")
    return artifact


def _predict(image_path, model_path):
    # Only load joblib files from a trusted source.
    artifact = joblib.load(model_path)
    if artifact.get("format_version") != FORMAT_VERSION:
        raise ValueError("This is an older model format. Retrain using this train_model.py.")
    features = load_image(image_path, artifact["image_size"], artifact["color_mode"])[None, :]
    coefficients = np.asarray(artifact["model"].predict(features)).reshape(-1)
    return artifact, coefficients


def predict_aberrations(image_path, model_path=MODEL_PATH, *, threshold=None):
    """Return every coefficient, or only estimates >= a supplied absolute threshold.

    Estimates are raw, not clipped to the training range. The threshold indicates
    estimated presence, not confidence. Default None returns ALL trained terms.
    """
    if threshold is not None and (not np.isfinite(threshold) or threshold < 0):
        raise ValueError("threshold must be finite and nonnegative, or None.")
    artifact, coefficients = _predict(image_path, model_path)
    return {name: float(value) for name, value in zip(artifact["term_names"], coefficients)
            if threshold is None or abs(value) >= threshold}


def predict_zernike_terms(image_path, model_path=MODEL_PATH, *, threshold=None):
    """Return all (n, m, estimate) triples in beam.py's input format."""
    if threshold is not None and (not np.isfinite(threshold) or threshold < 0):
        raise ValueError("threshold must be finite and nonnegative, or None.")
    artifact, coefficients = _predict(image_path, model_path)
    return [(int(n), int(m), float(value))
            for (n, m), value in zip(artifact["terms"], coefficients)
            if threshold is None or abs(value) >= threshold]


def predict_aberration(image_path, model_path=MODEL_PATH):
    """Legacy single-result interface for the unchanged runModel.py.

    Reports the strongest term even if all estimates are near zero. Use
    predict_aberrations for multiple terms and thresholding instead.
    """
    estimates = predict_aberrations(image_path, model_path)
    strongest = max(estimates, key=lambda name: abs(estimates[name]))
    return strongest, estimates[strongest]


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("action", nargs="?", choices=("train", "predict"), default="train")
    parser.add_argument("image", nargs="?", help="PNG to predict")
    parser.add_argument("--data-folder", type=Path, default=DATA_FOLDER)
    parser.add_argument("--model", type=Path, default=MODEL_PATH)
    parser.add_argument("--color-mode", choices=("RGB", "L"), default=COLOR_MODE)
    parser.add_argument("--image-size", type=int, default=IMAGE_SIZE[0], help="Square input size")
    parser.add_argument("--max-iter", type=int, default=300, help="Maximum training epochs")
    parser.add_argument("--test-size", type=float, default=0.20)
    parser.add_argument("--threshold", type=float, default=None,
                        help="Presence cutoff in waves (default: 0.02 for training; saved value for prediction)")
    args = parser.parse_args()
    try:
        if args.action == "train":
            if args.image:
                parser.error("Use 'predict image.png' to predict an image.")
            train_model(args.data_folder, args.model, (args.image_size, args.image_size),
                        args.color_mode, PRESENCE_THRESHOLD if args.threshold is None else args.threshold,
                        args.max_iter, args.test_size)
        else:
            if not args.image:
                parser.error("Provide an image: python train_model.py predict image.png")
            artifact, coefficients = _predict(args.image, args.model)
            threshold = artifact["presence_threshold"] if args.threshold is None else args.threshold
            if not np.isfinite(threshold) or threshold <= 0:
                raise ValueError("--threshold must be finite and positive.")
            present = []
            print("Estimated coefficients (waves):")
            for name, term, value, limits in zip(
                    artifact["term_names"], artifact["terms"], coefficients, artifact["strength_ranges"]):
                detected = abs(value) >= threshold
                if detected:
                    present.append(name)
                outside = " [outside training range]" if value < limits[0] or value > limits[1] else ""
                print(f"  {name:>8} {tuple(term)}: {value:.6f}"
                      f"  {'present' if detected else 'below threshold'}{outside}")
            print("Estimated present terms:", ", ".join(present) if present else "none")
            print(f"Presence threshold: {threshold:g} waves (not a confidence score)")
    except (ValueError, OSError, KeyError) as error:
        parser.exit(2, f"Error: {error}\n")


if __name__ == "__main__":
    main()
